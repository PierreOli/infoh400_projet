/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connexion;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pierr
 */
public class connexion {
    
        String Driver = "com.mysql.cj.jdbc.Driver";
        String UserName = "student";
        String PassWord= "1234";
            
        String url= "jdbc:mysql://localhost/projeth400?serverTimezone=Europe/Brussels";
        
    
    Connection conn; 
        public connexion(){
        try {
            this.conn = DriverManager.getConnection(url,UserName,PassWord);
        } catch (SQLException ex) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        public Connection getconnexion(){
        
       return conn;
    } 
        
    
}
